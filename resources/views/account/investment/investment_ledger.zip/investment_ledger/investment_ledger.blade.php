@extends('layouts.app')
@section('content')
    <div class="container mt-2">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            Investment Ledger List
                        </h3>
                    </div> <!-- /.card-body -->
                    @if (auth()->user()->role == 'SuperAdmin' || auth()->user()->role == 'Admin')
                        <div class="card-body p-3">
                            {{-- <form action="{{ route('ledger-list') }}" method="get"> --}}
                            <div class="row pb-3">
                                <div class="col-lg-3">
                                    <label for="start_date">Start Date</label>
                                    <input type="date" class="form-control" name="start_date" id="start_date"
                                        value="{{ date('Y-m-d') }}" />
                                </div>
                                <div class="col-lg-3">
                                    <label for="end_date">End Date</label>
                                    <input type="date" class="form-control" name="end_date" id="end_date"
                                        value="{{ date('Y-m-d') }}" />
                                </div>

                                <div class="col-lg-3">
                                    <label for="action">Action</label> <br />
                                    <button class="btn btn-success btn-block" onclick="viewInvestmentLedger();">
                                        <i class="fa fa-search"></i> Search
                                    </button>                                    
                                </div>
                            </div>
                            {{-- </form> --}}
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <div id="wrapper">

    </div>
    <div class="row">
        <div class="col-md-12 text-right">
            @php $date = date('d/m/Y'); @endphp
            <button
                class="mt-2 col-sm-1 btn btn-warning "onClick="document.title = '{{ $company_name }}-Investment Ledger-{{ $date }}'; printArea('printableArea');"
                style="margin-right:100px"><i class="fa fa-print" aria-hidden="true"></i> Print</button>
        </div>
    </div>
    <div id="printableArea">
        <div class="container" style="margin-top: 80px" id="main-table">
            <div class="row text-center">
                <div class="col-sm-12">
                    <h2>{{ $company_name }}</h2>
                    <h5><strong> Investment Ledger Report</strong></h5>
                    <h6>{{ $date }}</h6>
                </div>
            </div>
            @if (auth()->user()->role == 'SuperAdmin' || auth()->user()->role == 'Admin')
                <div class="row" style="margin-top: 20px">
                    <div class="col-sm-12">
                        <table class="table table-bordered">
                            <thead class="">
                                <tr>
                                    <th class="text-center">Client / Company</th>
                                    <th class="text-center">Investor</th>
                                    <th class="text-center">Invested Amount</th>
                                    <th class="text-center">Tentative Receivable Date</th>
                                    <th class="text-center">Note</th>
                                    <th class="text-center">Returned</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $total_returned = 0;
                                    $remaining_return = 0;
                                @endphp
                                @foreach ($invests as $invest)
                                {{-- @dd($invest) --}}
                                    @php
                                        $firstIteration = true;
                                    @endphp
                                    @foreach ($invest->return_invest as $r)
                                        <tr>
                                            @if ($firstIteration)
                                                <td rowspan="{{ count($invest->return_invest) }}" class="text-center">{{ $invest->client_name }}
                                                </td>
                                                <td rowspan="{{ count($invest->return_invest) }}" class="text-center">{{ $invest->investor }}
                                                </td>
                                                <td rowspan="{{ count($invest->return_invest) }}" class="text-center">
                                                    {{ $invest->amount }}</td>
                                                @php
                                                    $firstIteration = false;
                                                @endphp
                                            @endif

                                            <td class="text-center">{{ date('d/m/Y', strtotime($r->date)) }}</td>
                                            <td class="text-center">{{ $r->note }}</td>
                                            <td class="text-center">{{ $r->return_amount }}</td>
                                        </tr>
                                        @php
                                            $total_returned += $r->return_amount;
                                            $remaining_return = $invest->amount - $total_returned;
                                        @endphp
                                    @endforeach

                                    <tr>
                                        <td colspan="6" class="text-right"><strong>Total Returned:
                                                {{ $total_returned }}</strong></td>
                                    </tr>
                                    <tr>
                                        <td colspan="6" class="text-right"><strong>Remaining return:
                                                {{ $remaining_return }}</strong>
                                        </td>
                                    </tr>
                                    @php
                                        $total_returned = 0;
                                        $remaining_return = 0;
                                    @endphp
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif

        </div>
    </div>


@endsection

<script>
    function viewInvestmentLedger() {
        $('#main-table').hide();
        $('.btn-warning').hide();
        var start_date = document.getElementById('start_date').value;
        var end_date = document.getElementById('end_date').value;
        var url = "{{ route('investment_ledger_list') }}"

        $.ajax({
            type: 'GET',
            url: url,
            data: {
                start_date,
                end_date
            },
            success: function(data) {
                $('#wrapper').html(data);
            }
        });
    }
</script>

<script>
    function printArea(divId) {
    var printContents = document.getElementById(divId).innerHTML;
    var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;

    window.print();

    document.body.innerHTML = originalContents;
    }
</script>
    