<div class="row">
    @php $date = date('d/m/Y'); @endphp
    <div class="col-md-12 text-right">
        <button class="mt-2 col-sm-1 btn btn-warning" onClick="document.title = '{{$company_name}}-Investment Report-{{$date}}'; printDiv('printableArea'); " style="margin-right:100px"> <i class="fa fa-print"></i> Print </button>
    </div>
</div>

<div id="printableArea">

<div class="container" style="margin-top: 50px">
    <div class="row text-center">
        <div class="col-sm-12">
            <h2>{{$company_name}}</h2>
            <h5><strong>  Investment Report</strong></h5>
            <h6>{{date('d/m/Y',strtotime($start_date))}} - {{date('d/m/Y',strtotime($end_date))}}</h6>
        </div>
    </div>
    <div class="row" style="margin-top: 20px">
        <div class="col-sm-12">
            <table class="table table-bordered">
                <thead class="">
                    <tr>
                        <th class="text-center">Client / Company</th>
                        <th class="text-center">Investor</th>
                        <th class="text-center">Invested Amount</th>
                        <th class="text-center">Tentative Receivable Date</th>
                        <th class="text-center">Remarks</th>
                        <th class="text-center">Returned</th>
                        <th class="text-center">Profit</th>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $total_returned = 0;
                        $remaining_return = 0;
                    @endphp
                    @foreach ($data['invests'] as $invest)
                        @if ($invest->return_invest->isNotEmpty())
                            @php
                                $firstIteration = true;
                            @endphp
                            @foreach ($invest->return_invest as $r)
                                <tr>
                                    @if ($firstIteration)
                                        <td rowspan="{{ count($invest->return_invest) }}" class="text-center">
                                            {{ $invest->client_name }}</td>
                                        <td rowspan="{{ count($invest->return_invest) }}" class="text-center">
                                            {{ $invest->investor }}</td>
                                        <td rowspan="{{ count($invest->return_invest) }}" class="text-center">
                                            {{ $invest->amount }}</td>
                                        @php
                                            $firstIteration = false;
                                        @endphp
                                    @endif
                                    <td class="text-center">{{ date('d/m/Y', strtotime($r->date)) }}</td>
                                    <td class="text-center">{{ $r->note }}</td>
                                    <td class="text-center">{{ $r->return_amount }}</td>
                                    <td class="text-center">{{ $r->profit }}</td>
                                </tr>
                                @php
                                    $total_returned += $r->return_amount;
                                    $remaining_return = $invest->amount - $total_returned;
                                @endphp
                            @endforeach
                            <tr>
                                <td colspan="6" class="text-right"><strong>Total Returned:
                                        {{ $total_returned }}</strong></td>
                            </tr>
                            <tr>
                                <td colspan="6" class="text-right"><strong>Remaining return:
                                        {{ $remaining_return }}</strong></td>
                            </tr>
                            @php
                                $total_returned = 0;
                                $remaining_return = 0;
                            @endphp
                        @else
                            <tr>
                                <td class="text-center">{{ $invest->client_name }}</td>
                                <td class="text-center">{{ $invest->investor }}</td>
                                <td class="text-center">{{ $invest->amount }}</td>
                                <td class="text-center">{{date('d/m/Y', strtotime($invest->tentative_receivable_date))}}</td>
                                <td class="text-center">{{ $invest->purpose }}</td>
                                <td class="text-center">0</td>
                                <td class="text-center">0</td>
                            </tr>
                        @endif
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>

<script>
         function printDiv(divId) {
     var printContents = document.getElementById(divId).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();
     document.body.innerHTML = originalContents;
}
</script>
