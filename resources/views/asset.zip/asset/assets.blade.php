@extends('layouts.app')

@section('content')
    <div class="container mt-2">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card card-info card-outline">
                    <div class="card-header">
                        <h3 class="card-title col-sm-10">
                            Asset List
                        </h3>
                        <button class="text-end col-sm-2 btn btn-success btn-sm" data-toggle="modal" data-target="#modal-add">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add Asset
                        </button>
                    </div> <!-- /.card-body -->
                    <div class="card-body">
                        <form action="{{ route('asset_list') }}" method="get">
                            <div class="row pb-3">
                                {{-- <div class="col-lg-3">
                                    <label for="name">Asset Category</label>
                                    <select name="name" class="form-control">
                                        <option value="" selected>Select Category</option>
                                        @foreach ($asset_category as $category)
                                            <option value="{{ $category->id }}">{{ $category->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div> --}}
                                <div class="col-lg-3">
                                    <label for="group_id">Asset Group</label>
                                    <select name="group_id" class="form-control">
                                        <option value="" selected>Select Group</option>
                                        @foreach ($asset_groups as $asset_group)
                                            <option value="{{ $asset_group->id }}">{{ $asset_group->name }} ({{$asset_group->asset_category->name}})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-lg-3">
                                    <label for="name">Asset</label>
                                    <input type="text" class="form-control" name="name" placeholder="Asset Name">
                                </div>
                                <div class="col-lg-3">
                                    <label class="form-label">Asset Type</label>
                                    <select name="asset_type" class="form-control">
                                        <option value="">Select Asset Type</option>
                                        <option value="Fixed"> Fixed </option>
                                        <option value="Usable"> Usable </option>
                                        {{-- <option value="Current"> Current </option> --}}
                                    </select>
                                </div> 
                                <div class="col-lg-2">
                                    <label for="start_date">Start Date</label>
                                    <input type="date" class="form-control" name="start_date" />
                                </div>
                                <div class="col-lg-2">
                                    <label for="start_date">End Date</label>
                                    <input type="date" class="form-control" name="end_date" />
                                </div>

                                <div class="col-lg-2">
                                    <label for="action">Action</label> <br />
                                    <button class="btn btn-success btn-block">
                                        <i class="fa fa-search"></i> Search
                                    </button>
                                </div>
                            </div>
                        </form>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr class="bg-info text-center">
                                    <th>SL</th>
                                    <th>Asset Category</th>
                                    <th>Asset Type</th>
                                    <th>Asset Group</th>
                                    <th>Asset Name</th>
                                    <th>Asset Code</th>
                                    <th>Life Time</th>
                                    <th>Asset Image</th>
                                    <th>Description</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $serial = 0;
                                @endphp
                                @foreach ($assets as $asset)
                                    <tr>
                                        <td class="text-center">{{ ++$serial }}</td>
                                        <td class="text-center">{{ $asset->asset_group->asset_category->name ?? '' }}</td>
                                        <td class="text-center">{{ $asset->asset_type ?? '' }}</td>
                                        <td class="text-center">{{ $asset->asset_group->name ?? '' }} </td>
                                        <td class="text-center">{{ $asset->name ?? '' }}</td>
                                        <td class="text-center">{{ $asset->asset_code ?? '' }}</td>
                                        @if ($asset->life_time)
                                            <td class="text-center">{{ $asset->life_time ?? '' }} Years</td>
                                        @else
                                            <td class="text-center">{{ $asset->life_time ?? '' }}</td>
                                        @endif

                                        {{-- @dd($asset->image) --}}
                                        @if ($asset->image)
                                            <td class="text-center">
                                                <img src="{{ asset('upload_images/asset/' . $asset->image) }}"
                                                    height="70px" width="90px" />
                                            </td>
                                        @else
                                            <td class="text-center">
                                                <img src="{{ asset('upload_images/asset/default_image.jpg') }}"
                                                    alt="Asset Image" style="height: 70px; width: 90px;">
                                            </td>
                                        @endif

                                        <td class="text-center"
                                            style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                                            {{ $asset->description }}
                                        </td>
                                        <td class="text-center">
                                            <a data-toggle="modal" data-target=".view-modal-{{ $asset->id }}"><i
                                                    class="fa fa-eye pr-2 pl-2" style="color: rgb(78, 151, 78)"></i></a>
                                            <a data-toggle="modal" data-target=".update-modal-{{ $asset->id }}"
                                                style="padding:2px; color:white" class="btn btn-xs btn-info  mr-1">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="{{ route('asset_delete', $asset->id) }}"
                                                onclick="return confirm('Are you sure you want to delete?');"
                                                style="padding: 2px;" class="delete btn btn-xs btn-danger  mr-1">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="row pt-3">
                            <div class="col-lg-12">
                                {{ $assets->links() }}
                            </div>
                        </div>
                    </div><!-- /.card-body -->
                </div>
            </div>
        </div>
    </div>


    <!-- Add Modal -->
    <div class="modal fade" id="modal-add">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info">
                    <h4 class="modal-title">Add Asset</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('save_asset') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <div class="row">
                            {{-- <div class="col-lg-12">
                                <label for="category_id">Asset Category<i class="text-danger">*</i></label>
                                <select name="category_id" id="category_id" class="form-control form-select" required>
                                    <option value="" selected>Select Category</option>
                                    @foreach ($asset_category as $category)
                                        <option value="{{ $category->id }}">{{ $category->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div> --}}
                            <div class="col-lg-12">
                                <label for="group_id">Asset Group<i class="text-danger">*</i></label>
                                <select name="group_id" id="group_id" class="form-control form-select" required>
                                    <option value="" selected>Select Group</option>
                                    {{-- @dd($asset_groups) --}}
                                    @foreach ($asset_groups as $asset_group)
                                        <option value="{{ $asset_group->id }}">{{ $asset_group->name }}
                                            ({{ $asset_group->asset_category->name }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label class="form-label">Asset Name<i class="text-danger">*</i></label>
                                    <input type="text" class="form-control" name="name" placeholder="Asset Name"
                                        required>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label class="form-label">Asset Type<i class="text-danger">*</i></label>
                                    <select name="asset_type" id="asset_type" class="form-control" required>
                                        <option value="">Select Asset Type</option>
                                        <option value="Fixed"> Fixed </option>
                                        <option value="Usable"> Usable </option>
                                        {{-- <option value="Current"> Current </option> --}}
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-12" id="lifeTimeSection" style="display: none;">
                                <div class="mb-3">
                                    <label class="form-label">Life Time (Years)</label>
                                    <input type="number" class="form-control" name="life_time" placeholder="Life Time" min="0">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="image"> Asset Image</label>
                                    <input type="file" name="image" class="form-control" />
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea type="text" class="form-control" name="description" cols="4" rows="4"
                                        placeholder="Asset Description"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->



    <!-- Edit Modal -->
    @foreach ($assets as $asset)
        <div class="modal fade update update-modal-{{ $asset->id }}" id="exampleModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-info text-center">
                        <h5>Update Asset</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="{{ route('update_asset', $asset->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body">
                            <div class="row">
                                {{-- <div class="col-lg-12">
                                    <label for="category_id">Asset Category<i class="text-danger">*</i></label>
                                    <select name="category_id" id="edit_category_id_{{ $asset->id }}"
                                        class="form-control form-select" required>
                                        <option value="" selected>Select Category</option>
                                        @foreach ($asset_category as $category)
                                            <option value="{{ $category->id }}"
                                                @if ($category->id == $asset->category_id) selected @endif
                                                {{ $category->id == $asset->category_id ? 'selected' : '' }}>
                                                {{ $category->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div> --}}
                                <div class="col-lg-12">
                                    <label for="group_id">Asset Group<i class="text-danger">*</i></label>
                                    <select name="group_id" class="form-control form-select" required>
                                        <option value="" selected>Select Group</option>
                                        @foreach ($asset_groups as $asset_group)
                                            <option value="{{ $asset_group->id }}"
                                                @if ($asset_group->id == $asset->group_id) selected @endif>
                                                {{ $asset_group->name }} ({{ $asset_group->asset_category->name }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label class="form-label">Asset Name<i class="text-danger">*</i></label>
                                        <input type="text" class="form-control" value="{{ $asset->name }}"
                                            id="name" name="name" placeholder="Asset Name" required>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label class="form-label">Asset Type<i class="text-danger">*</i></label>
                                        <select name="asset_type" id="edit_asset_type_{{$asset->id}}" class="form-control" required>
                                            <option value="">Select Asset Type</option>
                                            <option value="Fixed" @if ($asset->asset_type == 'Fixed') selected @endif> Fixed
                                            </option>
                                            <option value="Usable" @if ($asset->asset_type == 'Usable') selected @endif>
                                                Usable </option>
                                            {{-- <option value="Current"> Current </option> --}}
                                        </select>
                                    </div>
                                </div>

                                @if ($asset->life_time)
                                    <div class="col-lg-12" id="lifeTimeSectionUpdate_{{ $asset->id }}">
                                        <div class="mb-3">
                                            <label class="form-label">Life Time (Years)</label>
                                            <input type="number" class="form-control" value="{{ $asset->life_time }}"
                                                name="life_time" placeholder="Life Time" min="0">
                                        </div>
                                    </div>
                                @else
                                    <div class="col-lg-12" id="lifeTimeSectionUpdate_{{ $asset->id }}"
                                        style="display: none;">
                                        <div class="mb-3">
                                            <label class="form-label">Life Time (Years)</label>
                                            <input type="number" class="form-control" value="{{ $asset->life_time }}"
                                                name="life_time" placeholder="Life Time" min="0">
                                        </div>
                                    </div>
                                @endif

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label for="image"> Asset Image </label>
                                        <input type="file" name="image" class="form-control" />
                                        @if ($asset->image)
                                            <img src="{{ asset('upload_images/asset/' . $asset->image) }}" height="70px"
                                                width="90px" />
                                        @else
                                            <img src="{{ asset('upload_images/asset/default_image.jpg') }}"
                                                height="70px" width="90px" />
                                        @endif
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label class="form-label">Description</label>
                                        <textarea type="text" class="form-control" cols="4" rows="4"
                                            name="description" id="description" placeholder="Asset Description">{{ $asset->description }}</textarea>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    @endforeach
    <!-- /.modal -->


    <!-- View Modal -->
    @foreach ($assets as $asset)
        <div class="modal fade view-modal-{{ $asset->id }}" id="exampleModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-info text-center">
                        <h5>View Asset</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <table class="table table-sm">
                                <tr>
                                    <th width="1%"></th>
                                    @if ($asset->image)
                                        <td class="text-center">
                                            <img src="{{ asset('upload_images/asset/' . $asset->image) }}" height="80px"
                                                width="100px" />
                                        </td>
                                    @else
                                        <td class="text-center">
                                            <img src="{{ asset('upload_images/asset/default_image.jpg') }}"
                                                alt="Asset Image" style="height: 80px; width: 100px;">
                                        </td>
                                    @endif
                                </tr>
                            </table>
                            <table class="table table-sm">
                                <tr>
                                    <th width="20%">Asset: </th>
                                    <td>{{ $asset->name }}</td>

                                    <th width="20%">Asset Category: </th>
                                    <td>{{ $asset->asset_group->asset_category->name ?? '' }}</td>

                                    <th width="20%">Asset Type: </th>
                                    <td>{{ $asset->asset_type }}</td>
                                </tr>
                            </table>
                            <table class="table table-sm">
                                <tr>
                                    <th width="20%">Asset Code: </th>
                                    <td>{{ $asset->asset_code }}</td>

                                    <th width="20%">Asset Group: </th>
                                    <td>{{ $asset->asset_group->name }}</td>

                                    @if ($asset->life_time)
                                        <th width="20%">Life Time: </th>
                                        <td>{{ $asset->life_time }} Years</td>
                                    @endif
                                </tr>
                            </table>
                            <table class="table table-sm">
                                <tr>
                                    <th width="20%">Description: </th>
                                    <td>
                                        {{ $asset->description }}</td>
                                </tr>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    @endforeach
    <!-- /.modal -->
@endsection
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('[id^="edit_asset_type_"]').change(function() {
            var selectedasset_type = $(this).val();
            var assetId = $(this).attr('id').split('_')[3];
            $.ajax({
                url: '/check-asset-type',
                type: 'POST',
                data: {
                    asset_type: selectedasset_type
                },
                dataType: 'json',
                success: function(response) {
                    var assetType = response.asset_type; 
                    if (assetType === 'Fixed') {
                        $('#lifeTimeSectionUpdate_' + assetId).show();
                    } else {
                        $('#lifeTimeSectionUpdate_' + assetId).hide();
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
        $('#asset_type').change(function() {
            var selectedasset_type = $(this).val();
            // console.log(selectedasset_type);
            $.ajax({
                url: '/check-asset-type',
                type: 'POST',
                data: {
                    asset_type: selectedasset_type
                },
                dataType: 'json',
                success: function(response) {
                    // console.log(response);
                    var assetType = response.asset_type; 
                    if (assetType === 'Fixed') {
                        $('#lifeTimeSection').show();
                    } else {
                        $('#lifeTimeSection').hide();
                    }
                },

                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>
